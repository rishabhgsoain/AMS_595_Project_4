import time
import numpy as np
import pandas as pd  # type: ignore
import sympy as sp   # type: ignore
import matplotlib.pyplot as plt

#  For a given function, creates a shortened Taylor series approximation.

    #  funcExpr: symbolic expression or function
        #  the approximation analytic function.
    #  xEnd, xStart: float
        #  the time frame in which the function will be assessed.
    #  degree: int
        #  the Taylor polynomial's maximum power, or truncation level.
    #  center: float
        #  the focal point of the series' expansion.
    #  numPoints: int
        #  number of points awarded for a numerical assessment.
        
def taylorApprox(funcExpr, xStart, xEnd, degree, center, numPoints=100):
    xSymbol = sp.symbols('x')
# This symFunction will convert function into symbolic expression
    symFunction = funcExpr(xSymbol) if callable(funcExpr) else sp.sympify(funcExpr)
# Add together all of the derivative terms to create the Taylor polynomial.
    truncatedSeries = 0
    for order in range(degree + 1):
        derivative = sp.diff(symFunction, xSymbol, order)
        truncatedSeries += (derivative.subs(xSymbol, center) / sp.factorial(order)) * (xSymbol - center) ** order
    truncatedSeries = sp.simplify(truncatedSeries)
# This funcNumeric will convert symFunction into fast numerical functions
    funcNumeric = sp.lambdify(xSymbol, symFunction, "numpy")
    seriesNumeric = sp.lambdify(xSymbol, truncatedSeries, "numpy")
# solving both true functions and approximation 
    xValues = np.linspace(xStart, xEnd, numPoints)
    approxValues = seriesNumeric(xValues)
    trueValues = funcNumeric(xValues)

    return xValues, approxValues, trueValues, truncatedSeries

# Plotting
def ploting():
   
    testFunction = lambda x: x * sp.sin(x)**2 + sp.cos(x)
    # Finding the values of approximations and function
    xValues, approxValues, trueValues, _ = taylorApprox(
        funcExpr=testFunction, xStart=-10, xEnd=10, degree=99, center=0.0, numPoints=100
    )

    plt.figure(figsize=(8, 4), dpi=150)
    plt.plot(xValues, trueValues, label="True Function")
    plt.plot(xValues, approxValues, linestyle="--", label="Taylor Approximation (m=99, c=0)")
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.title("Taylor Approximation: f(x) = x sin²(x) + cos(x)")
    plt.legend()
    plt.tight_layout()
    plt.show()


def taylorSweep(funcExpr, xStart, xEnd, initialDegree, finalDegree, degreeStep,
                center, numPoints=100, csvFilePath="taylor_values.csv"):
    
    # tracks the calculation time and total error when repeating the Taylor approximation for a number of truncation degrees.
    #  A CSV file with the findings is saved for subsequent review.
    
    xSymbol = sp.symbols('x')
    symFunction = funcExpr(xSymbol) if callable(funcExpr) else sp.sympify(funcExpr)
    funcNumeric = sp.lambdify(xSymbol, symFunction, "numpy")
# Creating a grid
    xValues = np.linspace(xStart, xEnd, numPoints)
    trueValues = funcNumeric(xValues)

    resultsList = []
# Applying loop for all the degrees
    for m in range(initialDegree, finalDegree + 1, degreeStep):
        startTime = time.perf_counter()

        _, approxValues, _, _ = taylorApprox(
            funcExpr=symFunction, xStart=xStart, xEnd=xEnd,
            degree=m, center=center, numPoints=numPoints
        )

        elapsedTime = time.perf_counter() - startTime
        totalError = np.sum(np.abs(trueValues - approxValues))

        resultsList.append({
            "degree": m,
            "totalError": float(totalError),
            "timeSeconds": float(elapsedTime)
        })
# Converting results to a CSV file
    resultsDF = pd.DataFrame.from_records(resultsList, columns=["degree", "totalError", "timeSeconds"])
    resultsDF.to_csv(csvFilePath, index=False)
    return resultsDF


if __name__ == "__main__":
    ploting()

    targetFunction = lambda x: x * sp.sin(x)**2 + sp.cos(x)
    resultsDF = taylorSweep(
        funcExpr=targetFunction,
        xStart=-10, xEnd=10,
        initialDegree=50, finalDegree=100, degreeStep=10,
        center=0.0, numPoints=200,
        csvFilePath="taylor_values.csv"
    )

    print(resultsDF)
    print("Wrote:", "taylor_values.csv")
