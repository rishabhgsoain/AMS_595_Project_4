import numpy as np
import matplotlib.pyplot as plt


# creates and displays the Mandelbrot set for the specified complex plane area.
#      float for xMin, xMax, yMin, and yMax
#          Visualize the complicated plane's range.
#      width, img Height: int
#          The resulting image's resolution.
#      maximum Iterations: int
#          number of times each point is iterated.
#      Differences Float is the threshold.
#          Divergence is measured using a threshold value.
#      savePath: str to save the Mandelbrot picture that was created.

#      mask: np.ndarray, a Boolean array that indicates which points are part of the Mandelbrot set, is returned.


def generateMandelbrot(xMin=-2.0, xMax=1.0, yMin=-1.5, yMax=1.5,
                       imgWidth=1200, imgHeight=1200,
                       maxIterations=200, divergenceThreshold=50.0,
                       savePath="mandelbrot.png"):


    #Create a complex number grid across the designated area using the formula c = x + i*y.
    xValues = np.linspace(xMin, xMax, imgWidth, dtype=np.float64)
    yValues = np.linspace(yMin, yMax, imgHeight, dtype=np.float64)
    realGrid, imagGrid = np.meshgrid(xValues, yValues, indexing="xy")
    complexPlane = realGrid + 1j * imagGrid

    #Set a boolean mask to track bounded points and initialize z = 0 for all points.
    zValues = np.zeros_like(complexPlane)
    activePoints = np.ones(complexPlane.shape, dtype=bool)

    # Iteratively applying the Mandelbrot update
    for _ in range(maxIterations):
        zValues[activePoints] = zValues[activePoints] ** 2 + complexPlane[activePoints]
        activePoints = np.abs(zValues) < divergenceThreshold  # points still bounded

    # Creating a mask for points that never diverged
    boundedMask = np.abs(zValues) < divergenceThreshold

    # Plot
    plt.figure(figsize=(6, 6), dpi=200)
    plt.imshow(boundedMask, extent=[xMin, xMax, yMin, yMax])
    plt.xlabel("Re(c)")
    plt.ylabel("Im(c)")
    plt.title("Mandelbrot Set")
    plt.gray()
    plt.tight_layout()
    plt.savefig(savePath, bbox_inches="tight")
    plt.show()

    return boundedMask


if __name__ == "__main__":
    generateMandelbrot()
