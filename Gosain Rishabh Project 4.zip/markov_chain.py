import numpy as np

# Setting a random seed so that random numbers remain same everytime. 
randomGen = np.random.default_rng(seed=2025)


def createRandomTransitionMatrix(numStates=5):
    # Make a row-stochastic transition matrix at random (rows add up to 1).
    #  The transition probabilities for a single state are represented by each row.
    transitionMatrix = randomGen.random((numStates, numStates))
    transitionMatrix /= transitionMatrix.sum(axis=1, keepdims=True)
    return transitionMatrix


def createRandomProbabilityVector(numStates=5):
    #   Make a random probability vector with a total of 1 for all non-negative elements.
    #  depicts the initial distribution of probabilities among states.
    probVector = randomGen.random(numStates)
    probVector /= probVector.sum()
    return probVector


def evolveDistribution(probVector, transitionMatrix, numSteps=50):
#     Using the formula p_next = P^T * p for a certain number of steps, evolve the probability distribution.
#      prob Vector: np.ndarray
#          The initial distribution of probabilities.
#      change Matrix: np.ndarray
#          The matrix of Markov transitions.
#      Number Procedure: int
#          How many transitional stages should be used?
#      Returns evolvedVector: np.ndarray The probability distribution following the transitions of 'numSteps'.
    evolvedVector = probVector.copy()
    for _ in range(numSteps):
        evolvedVector = transitionMatrix.T @ evolvedVector
    return evolvedVector


def computeStationaryDistribution(transitionMatrix):
   # Find π, the stationary distribution of the Markov chain.   
   # The stationary vector satisfies this: P^T * π = π    
   # The result is the normalized eigenvector of P^T corresponding to the eigenvalue nearest to 1.
    
    eigenValues, eigenVectors = np.linalg.eig(transitionMatrix.T)

    # Identifying the eigenvector associated with eigenvalues close to 1
    closestIndex = np.argmin(np.abs(eigenValues - 1.0))
    stationaryVector = np.real(eigenVectors[:, closestIndex])

    if np.allclose(stationaryVector, 0):
        stationaryVector = np.ones(transitionMatrix.shape[0])

    # Make sure the entries are not negative and adjust the sum to 1.
    stationaryVector = np.abs(stationaryVector)
    totalSum = stationaryVector.sum()

    if totalSum == 0 or np.isnan(totalSum): 
        stationaryVector = np.ones(transitionMatrix.shape[0]) / transitionMatrix.shape[0]
    else:
        stationaryVector /= totalSum

    return stationaryVector


if __name__ == "__main__":
    numStates = 5

    # # Create the initial distribution and random transition matrix.
    transitionMatrix = createRandomTransitionMatrix(numStates)
    initialProb = createRandomProbabilityVector(numStates)

    # Calculate the stationary distribution after 50 steps of system evolution.
    probAfter50 = evolveDistribution(initialProb, transitionMatrix, numSteps=50)
    stationaryDist = computeStationaryDistribution(transitionMatrix)

    # Examine the differences between the stationary and evolved distributions.
    diffVector = np.abs(probAfter50 - stationaryDist)

    print("Transition Matrix P:\n", transitionMatrix)
    print("\nInitial Distribution p₀:", initialProb)
    print("\nDistribution after 50 steps p₅₀:", probAfter50)
    print("\nStationary Distribution π:", stationaryDist)
    print("\nComponent-wise |p₅₀ - π|:", diffVector)
    print("\nMax Difference:", diffVector.max())
    print("Match within 1e-5? ->", np.all(diffVector < 1e-5))
